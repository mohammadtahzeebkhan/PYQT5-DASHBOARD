### New-PySide6-ui-design
This design was influenced by the original designer [Pinterest](https://www.pinterest.com/pin/412079434655472784/).

> You can watch quick video on [YouTube](https://youtu.be/cjtee7OhLpU).

![Poster](/resources/clone-uidashboard.png)
